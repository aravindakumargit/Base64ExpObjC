//
//  ViewController.m
//  Base64ExpObjC
//
//  Created by Aravindakumar Arunachalam on 27/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSString *str;
    NSString *EncodeStr;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self encodingStr];
    [self decodingStr];
    UIImage *img1 = [UIImage imageNamed:@"placeholder.png"];
    EncodeStr = [self encodeToBase64String:img1];
    NSLog(@"EcodedImd is %@",EncodeStr);
    [self.imgView setImage:[self decodeBase64ToImage:EncodeStr]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)encodingStr{
    NSString *plainString = @"foo";
    NSData *plainData = [plainString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [plainData base64EncodedStringWithOptions:0];
    str=base64String;
    NSLog(@"%@", base64String);
}
-(void)decodingStr{
   
    NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:str options:0];
    NSString *decodedString = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];
 
    NSLog(@"decoded is %@", decodedString);
}
- (NSString *)encodeToBase64String:(UIImage *)image {
    return [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
}

- (UIImage *)decodeBase64ToImage:(NSString *)strEncodeData {
    NSData *data = [[NSData alloc]initWithBase64EncodedString:strEncodeData options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSString *EcodedString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"encoded img is %@",EcodedString);

    return [UIImage imageWithData:data];
}
@end
